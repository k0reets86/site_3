<?php
/**
 * Default RSS Sources for AI News Control Center
 * 60+ sources for Ukrainians in Germany/Bavaria/Munich
 * Categories: official, media, ukraine, transport, weather, economy, emergency, international
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get all default RSS sources
 */
function aincc_get_default_sources() {
    return [
        // ==========================================
        // OFFICIAL SOURCES (Trust: 1.0)
        // ==========================================

        // German Government
        [
            'id' => 'bundesregierung',
            'name' => 'Bundesregierung',
            'url' => 'https://www.bundesregierung.de/breg-de/service/rss/992816',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'official',
            'trust_score' => 1.0,
            'fetch_interval' => 15,
            'priority' => 1,
            'enabled' => 1,
        ],
        [
            'id' => 'bamf',
            'name' => 'BAMF - Bundesamt für Migration',
            'url' => 'https://www.bamf.de/SiteGlobals/Functions/RSSFeed/DE/Feed.xml',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'official',
            'trust_score' => 1.0,
            'fetch_interval' => 30,
            'priority' => 1,
            'enabled' => 1,
        ],
        [
            'id' => 'bayern_staatsregierung',
            'name' => 'Bayerische Staatsregierung',
            'url' => 'https://www.bayern.de/rss/',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Bayern',
            'category' => 'official',
            'trust_score' => 1.0,
            'fetch_interval' => 30,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'muenchen_de',
            'name' => 'Stadt München',
            'url' => 'https://www.muenchen.de/rss',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'official',
            'trust_score' => 1.0,
            'fetch_interval' => 30,
            'priority' => 1,
            'enabled' => 1,
        ],
        [
            'id' => 'arbeitsagentur',
            'name' => 'Bundesagentur für Arbeit',
            'url' => 'https://www.arbeitsagentur.de/rss/presse',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'official',
            'trust_score' => 1.0,
            'fetch_interval' => 60,
            'priority' => 2,
            'enabled' => 1,
        ],

        // ==========================================
        // GERMAN MEDIA (Trust: 0.9)
        // ==========================================

        // National News
        [
            'id' => 'tagesschau',
            'name' => 'Tagesschau (ARD)',
            'url' => 'https://www.tagesschau.de/xml/rss2',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.95,
            'fetch_interval' => 5,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'tagesschau_inland',
            'name' => 'Tagesschau Inland',
            'url' => 'https://www.tagesschau.de/xml/rss2_https/inland/',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.95,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'dw_german',
            'name' => 'Deutsche Welle Deutsch',
            'url' => 'https://rss.dw.com/rdf/rss-de-all',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.95,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'zeit',
            'name' => 'ZEIT Online',
            'url' => 'https://newsfeed.zeit.de/index',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'spiegel',
            'name' => 'Der Spiegel',
            'url' => 'https://www.spiegel.de/schlagzeilen/index.rss',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'faz',
            'name' => 'Frankfurter Allgemeine',
            'url' => 'https://www.faz.net/rss/aktuell/',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'sueddeutsche',
            'name' => 'Süddeutsche Zeitung',
            'url' => 'https://rss.sueddeutsche.de/rss/Topthemen',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'welt',
            'name' => 'Die Welt',
            'url' => 'https://www.welt.de/feeds/latest.rss',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'media',
            'trust_score' => 0.85,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],

        // Bavarian Regional
        [
            'id' => 'br24',
            'name' => 'BR24 Bayern',
            'url' => 'https://www.br.de/nachrichten/feed/rss',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Bayern',
            'category' => 'media',
            'trust_score' => 0.95,
            'fetch_interval' => 5,
            'priority' => 1,
            'enabled' => 1,
        ],
        [
            'id' => 'br24_muenchen',
            'name' => 'BR24 München',
            'url' => 'https://www.br.de/nachrichten/bayern/muenchen,QdBjJg5/rss',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'media',
            'trust_score' => 0.95,
            'fetch_interval' => 5,
            'priority' => 1,
            'enabled' => 1,
        ],
        [
            'id' => 'merkur',
            'name' => 'Münchner Merkur',
            'url' => 'https://www.merkur.de/lokales/muenchen/rssfeed.rdf',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'media',
            'trust_score' => 0.85,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'tz_muenchen',
            'name' => 'tz München',
            'url' => 'https://www.tz.de/muenchen/rssfeed.rdf',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'media',
            'trust_score' => 0.80,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'abendzeitung',
            'name' => 'Abendzeitung München',
            'url' => 'https://www.abendzeitung-muenchen.de/rss/muenchen.xml',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'media',
            'trust_score' => 0.80,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],

        // ==========================================
        // UKRAINIAN SOURCES (Trust: 0.85)
        // ==========================================

        [
            'id' => 'ukrinform_de',
            'name' => 'Ukrinform Deutsch',
            'url' => 'https://www.ukrinform.de/rss/block-lastnews',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.85,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'ukrinform_ua',
            'name' => 'Укрінформ',
            'url' => 'https://www.ukrinform.ua/rss/block-lastnews',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.85,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'pravda_ua',
            'name' => 'Українська правда',
            'url' => 'https://www.pravda.com.ua/rss/',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.85,
            'fetch_interval' => 5,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'eurointegration',
            'name' => 'Європейська правда',
            'url' => 'https://www.eurointegration.com.ua/rss/news.xml',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.85,
            'fetch_interval' => 15,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'liga_ua',
            'name' => 'Ліга Новини',
            'url' => 'https://news.liga.net/ua/rss.xml',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.80,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'unian_ua',
            'name' => 'УНІАН',
            'url' => 'https://rss.unian.net/site/news_ukr.rss',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.80,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'suspilne',
            'name' => 'Суспільне Новини',
            'url' => 'https://suspilne.media/rss/ukr.rss',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'nv_ua',
            'name' => 'НВ (Новое Время)',
            'url' => 'https://nv.ua/rss/all.xml',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.80,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'dw_ukraine',
            'name' => 'Deutsche Welle Україна',
            'url' => 'https://rss.dw.com/rdf/rss-ukr-all',
            'method' => 'rss',
            'lang' => 'ua',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.95,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],

        // ==========================================
        // TRANSPORT (Trust: 0.95) - DISABLED: Most transport RSS feeds are broken
        // ==========================================

        // MVV, DB, ADAC - RSS feeds discontinued or require authentication
        // Keeping disabled for now until working URLs are found

        // ==========================================
        // WEATHER & EMERGENCY (Trust: 1.0) - DISABLED: RSS feeds discontinued
        // ==========================================

        // DWD and NINA use different API formats now

        // ==========================================
        // ECONOMY (Trust: 0.85)
        // ==========================================

        [
            'id' => 'handelsblatt',
            'name' => 'Handelsblatt',
            'url' => 'https://www.handelsblatt.com/contentexport/feed/top-themen',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'economy',
            'trust_score' => 0.90,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'wiwo',
            'name' => 'WirtschaftsWoche',
            'url' => 'https://www.wiwo.de/contentexport/feed/rss/schlagzeilen',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'economy',
            'trust_score' => 0.85,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'manager_magazin',
            'name' => 'Manager Magazin',
            'url' => 'https://www.manager-magazin.de/static/site/rss/schlagzeilen.xml',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'economy',
            'trust_score' => 0.85,
            'fetch_interval' => 20,
            'priority' => 4,
            'enabled' => 1,
        ],

        // ==========================================
        // INTERNATIONAL (Trust: 0.85-0.95)
        // ==========================================

        [
            'id' => 'euronews_de',
            'name' => 'Euronews Deutsch',
            'url' => 'https://de.euronews.com/rss',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'EU',
            'category' => 'international',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        // Reuters German RSS - service discontinued
        // BBC German RSS - service discontinued
        // AP News RSS - requires different URL format now

        // ==========================================
        // GOOGLE NEWS (Trust: 0.85)
        // ==========================================

        [
            'id' => 'google_news_ukraine_de',
            'name' => 'Google News: Ukraine (DE)',
            'url' => 'https://news.google.com/rss/search?q=Ukraine&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Ukraine',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_ukrainer_deutschland',
            'name' => 'Google News: Ukrainer in Deutschland',
            'url' => 'https://news.google.com/rss/search?q=Ukrainer+Deutschland+Flüchtlinge&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 15,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_buergergeld',
            'name' => 'Google News: Bürgergeld',
            'url' => 'https://news.google.com/rss/search?q=Bürgergeld+2024&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 30,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_aufenthaltstitel',
            'name' => 'Google News: Aufenthaltstitel',
            'url' => 'https://news.google.com/rss/search?q=Aufenthaltstitel+Ukraine&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 30,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_muenchen',
            'name' => 'Google News: München',
            'url' => 'https://news.google.com/rss/search?q=München+aktuell&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 15,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_bayern',
            'name' => 'Google News: Bayern',
            'url' => 'https://news.google.com/rss/search?q=Bayern+aktuell&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Bayern',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_integration',
            'name' => 'Google News: Integration Deutschland',
            'url' => 'https://news.google.com/rss/search?q=Integration+Migranten+Deutschland&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 30,
            'priority' => 4,
            'enabled' => 1,
        ],
        [
            'id' => 'google_news_arbeit_job',
            'name' => 'Google News: Arbeit Jobs',
            'url' => 'https://news.google.com/rss/search?q=Arbeitsmarkt+Jobs+Deutschland&hl=de&gl=DE&ceid=DE:de',
            'method' => 'google_news',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'aggregator',
            'trust_score' => 0.85,
            'fetch_interval' => 30,
            'priority' => 4,
            'enabled' => 1,
        ],

        // ==========================================
        // SOCIAL / CULTURE (Trust: 0.80)
        // ==========================================

        [
            'id' => 'muenchenticket',
            'name' => 'München Ticket Events',
            'url' => 'https://www.muenchenticket.de/rss/events.xml',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'München',
            'category' => 'culture',
            'trust_score' => 0.80,
            'fetch_interval' => 60,
            'priority' => 5,
            'enabled' => 0,
        ],

        // ==========================================
        // RUSSIAN-LANGUAGE SOURCES (Trust: 0.75-0.85)
        // ==========================================

        [
            'id' => 'dw_russian',
            'name' => 'Deutsche Welle Русский',
            'url' => 'https://rss.dw.com/rdf/rss-ru-all',
            'method' => 'rss',
            'lang' => 'ru',
            'geo' => 'International',
            'category' => 'international',
            'trust_score' => 0.95,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'meduza_ru',
            'name' => 'Meduza',
            'url' => 'https://meduza.io/rss/all',
            'method' => 'rss',
            'lang' => 'ru',
            'geo' => 'International',
            'category' => 'international',
            'trust_score' => 0.85,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'novaya_gazeta',
            'name' => 'Новая газета Европа',
            'url' => 'https://novayagazeta.eu/rss/all',
            'method' => 'rss',
            'lang' => 'ru',
            'geo' => 'International',
            'category' => 'international',
            'trust_score' => 0.85,
            'fetch_interval' => 20,
            'priority' => 3,
            'enabled' => 1,
        ],

        // ==========================================
        // ENGLISH-LANGUAGE SOURCES (Trust: 0.90)
        // ==========================================

        [
            'id' => 'dw_english',
            'name' => 'Deutsche Welle English',
            'url' => 'https://rss.dw.com/rdf/rss-en-all',
            'method' => 'rss',
            'lang' => 'en',
            'geo' => 'International',
            'category' => 'international',
            'trust_score' => 0.95,
            'fetch_interval' => 15,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'bbc_world',
            'name' => 'BBC World',
            'url' => 'https://feeds.bbci.co.uk/news/world/rss.xml',
            'method' => 'rss',
            'lang' => 'en',
            'geo' => 'International',
            'category' => 'international',
            'trust_score' => 0.95,
            'fetch_interval' => 10,
            'priority' => 3,
            'enabled' => 1,
        ],
        [
            'id' => 'kyiv_independent',
            'name' => 'Kyiv Independent',
            'url' => 'https://kyivindependent.com/feed/',
            'method' => 'rss',
            'lang' => 'en',
            'geo' => 'Ukraine',
            'category' => 'ukraine',
            'trust_score' => 0.90,
            'fetch_interval' => 10,
            'priority' => 2,
            'enabled' => 1,
        ],
        [
            'id' => 'euractiv',
            'name' => 'Euractiv',
            'url' => 'https://www.euractiv.com/feed/',
            'method' => 'rss',
            'lang' => 'en',
            'geo' => 'EU',
            'category' => 'international',
            'trust_score' => 0.90,
            'fetch_interval' => 20,
            'priority' => 4,
            'enabled' => 1,
        ],

        // ==========================================
        // TECH / DIGITALIZATION (Trust: 0.85)
        // ==========================================

        [
            'id' => 'heise',
            'name' => 'Heise Online',
            'url' => 'https://www.heise.de/rss/heise-top-atom.xml',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'tech',
            'trust_score' => 0.85,
            'fetch_interval' => 20,
            'priority' => 4,
            'enabled' => 0,
        ],
        [
            'id' => 'golem',
            'name' => 'Golem.de',
            'url' => 'https://rss.golem.de/rss.php?feed=ATOM1.0',
            'method' => 'rss',
            'lang' => 'de',
            'geo' => 'Deutschland',
            'category' => 'tech',
            'trust_score' => 0.85,
            'fetch_interval' => 20,
            'priority' => 4,
            'enabled' => 0,
        ],
    ];
}

/**
 * Get Google News search queries for specific topics
 */
function aincc_get_google_news_topics() {
    return [
        // Ukrainian-specific topics
        'ukraine_krieg' => 'Ukraine+Krieg+aktuell',
        'ukraine_hilfe' => 'Ukraine+Hilfe+Deutschland',
        'ukrainer_integration' => 'Ukrainer+Integration+Deutschland',
        'ukraine_flucht' => 'Ukraine+Flüchtlinge+Deutschland',

        // Migration topics
        'aufenthaltstitel' => 'Aufenthaltstitel+2024',
        'buergergeld' => 'Bürgergeld+Erhöhung',
        'kindergeld' => 'Kindergeld+2024',
        'integrationskurs' => 'Integrationskurs+Deutschland',

        // Munich/Bavaria specific
        'muenchen_aktuell' => 'München+aktuell+News',
        'bayern_politik' => 'Bayern+Politik+Söder',
        'mvv_muenchen' => 'MVV+München+Störung',

        // Work & Economy
        'fachkraefte' => 'Fachkräftemangel+Deutschland',
        'mindestlohn' => 'Mindestlohn+2024',
        'ausbildung' => 'Ausbildung+Deutschland+2024',

        // General Germany
        'bundesregierung' => 'Bundesregierung+Beschluss',
        'ampel_koalition' => 'Ampel+Koalition+Gesetz',
    ];
}

/**
 * Build Google News RSS URL for a search query
 */
function aincc_build_google_news_url($query, $lang = 'de', $country = 'DE') {
    $encoded_query = urlencode($query);
    return "https://news.google.com/rss/search?q={$encoded_query}&hl={$lang}&gl={$country}&ceid={$country}:{$lang}";
}
