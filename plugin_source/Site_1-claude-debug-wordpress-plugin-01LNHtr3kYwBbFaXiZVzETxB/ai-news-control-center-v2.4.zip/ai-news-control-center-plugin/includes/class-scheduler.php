<?php
/**
 * Scheduler
 * Manages cron jobs and scheduled tasks with memory/time protection
 *
 * KEY SAFETY FEATURES:
 * 1. Memory limit checks before processing
 * 2. Time limit enforcement
 * 3. Batch processing to prevent overload
 * 4. Lock mechanism to prevent concurrent runs
 * 5. Error isolation - one failure doesn't stop others
 */

if (!defined('ABSPATH')) {
    exit;
}

class AINCC_Scheduler {

    /**
     * Memory limit for batch operations (in bytes)
     */
    private $memory_limit;

    /**
     * Max execution time for cron jobs
     */
    private $max_execution_time = 120;

    /**
     * Lock transient prefix
     */
    private const LOCK_PREFIX = 'aincc_cron_lock_';

    /**
     * Lock timeout in seconds
     */
    private const LOCK_TIMEOUT = 300;

    /**
     * Constructor
     */
    public function __construct() {
        // Calculate memory limit (use 80% of available, max 256MB)
        $configured = AINCC_Settings::get('max_memory_mb', 256);
        $this->memory_limit = min($configured, 256) * 1024 * 1024;
    }

    /**
     * Check if memory is sufficient to continue
     */
    private function has_memory_available(): bool {
        $used = memory_get_usage(true);
        $available = $this->memory_limit - $used;

        // Need at least 32MB free
        return $available > (32 * 1024 * 1024);
    }

    /**
     * Acquire a lock for a cron job
     */
    private function acquire_lock(string $job): bool {
        $lock_key = self::LOCK_PREFIX . $job;
        $existing = get_transient($lock_key);

        if ($existing !== false) {
            // Lock exists, check if it's stale
            AINCC_Logger::warning("Lock exists for {$job}, skipping");
            return false;
        }

        // Set lock
        set_transient($lock_key, time(), self::LOCK_TIMEOUT);
        return true;
    }

    /**
     * Release a lock
     */
    private function release_lock(string $job): void {
        delete_transient(self::LOCK_PREFIX . $job);
    }

    /**
     * Fetch sources from RSS feeds
     * @param bool $force If true, fetch all sources ignoring time interval (for manual triggers)
     */
    public function fetch_sources(bool $force = false): array {
        $job = 'fetch_sources';
        $result = ['success' => false, 'fetched' => 0, 'errors' => [], 'sources_processed' => 0];

        AINCC_Logger::info('Scheduler: fetch_sources called', ['force' => $force]);

        if (!$this->acquire_lock($job)) {
            AINCC_Logger::warning('Scheduler: lock not acquired for fetch_sources');
            $result['error'] = 'Задача уже выполняется. Попробуйте через несколько минут.';
            return $result;
        }

        AINCC_Logger::info('Scheduler: lock acquired, starting fetch');

        try {
            // Get RSS parser - ensure it's loaded
            $rss_parser = aincc_get('rss_parser');

            if (!$rss_parser) {
                AINCC_Logger::debug('Scheduler: RSS parser not in container, loading directly');
                // Try to load directly
                if (!class_exists('AINCC_RSS_Parser')) {
                    require_once AINCC_PLUGIN_DIR . 'includes/class-rss-parser.php';
                }
                $rss_parser = new AINCC_RSS_Parser();
            }

            // Use the RSS parser's fetch_all_sources which now returns results
            $fetch_result = $rss_parser->fetch_all_sources($force);

            AINCC_Logger::info('Scheduler: fetch_all_sources completed', [
                'result_type' => gettype($fetch_result),
                'result' => is_array($fetch_result) ? array_diff_key($fetch_result, ['sources_list' => 1]) : $fetch_result,
            ]);

            $this->release_lock($job);

            if (is_array($fetch_result)) {
                // Ensure success is set
                $fetch_result['success'] = $fetch_result['success'] ?? true;
                return $fetch_result;
            }

            return ['success' => true, 'message' => 'Сбор завершен', 'fetched' => 0];

        } catch (Throwable $e) {
            AINCC_Logger::error('Fetch sources failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            $this->release_lock($job);
            return ['success' => false, 'error' => 'Ошибка сбора: ' . $e->getMessage()];
        }
    }

    /**
     * Process content queue (AI processing)
     * Delegates to content_processor which handles raw_item_id correctly
     */
    public function process_queue(): array {
        $job = 'process_queue';
        $result = ['success' => false, 'processed' => 0, 'errors' => []];

        AINCC_Logger::info('Scheduler: process_queue called');

        if (!$this->acquire_lock($job)) {
            AINCC_Logger::warning('Scheduler: lock not acquired for process_queue');
            $result['error'] = 'Обработка уже выполняется';
            return $result;
        }

        try {
            // Get or create content processor
            $processor = aincc_get('content_processor');

            if (!$processor) {
                AINCC_Logger::debug('Scheduler: Content processor not in container, loading directly');
                if (!class_exists('AINCC_Content_Processor')) {
                    require_once AINCC_PLUGIN_DIR . 'includes/class-content-processor.php';
                }
                $processor = new AINCC_Content_Processor();
            }

            // Delegate to content processor's process_queue which handles raw_item_id
            // But call process_item directly for each queue item to track results
            $db = new AINCC_Database();
            $start_time = time();
            $batch_size = (int) AINCC_Settings::get('batch_size', 5);
            $processed = 0;

            // Get pending items
            $queue_items = $db->get_queue_items('pending', $batch_size);

            AINCC_Logger::info('Scheduler: queue items found', ['count' => count($queue_items)]);

            if (empty($queue_items)) {
                $this->release_lock($job);
                return [
                    'success' => true,
                    'processed' => 0,
                    'message' => 'Очередь пуста. Сначала соберите новости.',
                ];
            }

            foreach ($queue_items as $item) {
                // Check time limit
                if ((time() - $start_time) > ($this->max_execution_time - 30)) {
                    AINCC_Logger::warning('Process timeout approaching', ['processed' => $processed]);
                    break;
                }

                // Check memory
                if (!$this->has_memory_available()) {
                    AINCC_Logger::warning('Memory limit approaching', ['processed' => $processed]);
                    break;
                }

                try {
                    // Mark as processing
                    $db->update_queue_status($item->id, 'processing');

                    // Get the raw_item_id from queue item (RSS items use raw_item_id, manual uses article_id)
                    $raw_item_id = $item->raw_item_id ?? null;
                    $article_id = $item->article_id ?? null;

                    AINCC_Logger::debug('Processing queue item', [
                        'queue_id' => $item->id,
                        'raw_item_id' => $raw_item_id,
                        'article_id' => $article_id,
                        'job_type' => $item->job_type ?? 'unknown',
                    ]);

                    if ($raw_item_id) {
                        // RSS item - use process_item
                        $process_result = $processor->process_item($raw_item_id);
                        $db->update_queue_status($item->id, 'completed');
                        $processed++;
                        AINCC_Logger::info("Processed raw item", ['raw_item_id' => $raw_item_id, 'result' => $process_result]);
                    } elseif ($article_id) {
                        // Manual article
                        $process_result = $processor->process_article($article_id);
                        if ($process_result) {
                            $db->update_queue_status($item->id, 'completed');
                            $processed++;
                        } else {
                            $db->update_queue_status($item->id, 'failed', 'Processing returned false');
                            $result['errors'][] = ['article_id' => $article_id, 'error' => 'Processing failed'];
                        }
                    } else {
                        AINCC_Logger::error('Queue item has no raw_item_id or article_id', ['item' => $item]);
                        $db->update_queue_status($item->id, 'failed', 'No item ID in payload');
                        $result['errors'][] = ['queue_id' => $item->id, 'error' => 'No item ID'];
                    }

                } catch (Throwable $e) {
                    $db->update_queue_status($item->id, 'failed', $e->getMessage());
                    $result['errors'][] = [
                        'queue_id' => $item->id,
                        'error' => $e->getMessage(),
                    ];
                    AINCC_Logger::error("Failed to process queue item", [
                        'queue_id' => $item->id,
                        'error' => $e->getMessage(),
                    ]);
                }
            }

            $result['success'] = true;
            $result['processed'] = $processed;
            $result['message'] = "Обработано {$processed} элементов";

            AINCC_Logger::info('Queue processing completed', $result);

        } catch (Throwable $e) {
            $result['error'] = $e->getMessage();
            AINCC_Logger::error('Queue processing failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
        } finally {
            $this->release_lock($job);
        }

        return $result;
    }

    /**
     * Auto publish approved articles
     */
    public function auto_publish(): array {
        $job = 'auto_publish';
        $result = ['success' => false, 'published' => 0, 'errors' => []];

        // Check if auto-publish is enabled
        if (!AINCC_Settings::get('auto_publish_enabled', false)) {
            $result['success'] = true;
            $result['message'] = 'Auto-publish disabled';
            return $result;
        }

        if (!$this->acquire_lock($job)) {
            $result['error'] = 'Job already running';
            return $result;
        }

        try {
            $publisher = aincc_get('publisher');
            $db = aincc_get('database');

            if (!$publisher || !$db) {
                throw new Exception('Required components not available');
            }

            $delay_minutes = (int) AINCC_Settings::get('auto_publish_delay', 10);
            $max_per_run = 5;

            // Get approved drafts ready for publishing
            $drafts = $db->get_drafts_for_auto_publish($delay_minutes, $max_per_run);

            if (empty($drafts)) {
                $result['success'] = true;
                $result['message'] = 'No drafts ready for auto-publish';
                return $result;
            }

            $published = 0;

            foreach ($drafts as $draft) {
                try {
                    $pub_result = $publisher->publish($draft->id);

                    if ($pub_result['success']) {
                        $published++;
                    } else {
                        $result['errors'][] = [
                            'draft_id' => $draft->id,
                            'error' => $pub_result['error'] ?? 'Unknown error'
                        ];
                    }

                } catch (Throwable $e) {
                    $result['errors'][] = [
                        'draft_id' => $draft->id,
                        'error' => $e->getMessage()
                    ];
                    AINCC_Logger::error("Auto-publish failed for draft", [
                        'draft_id' => $draft->id,
                        'error' => $e->getMessage()
                    ]);
                }
            }

            $result['success'] = true;
            $result['published'] = $published;

            if ($published > 0) {
                AINCC_Logger::info('Auto-publish completed', $result);
            }

        } catch (Throwable $e) {
            $result['error'] = $e->getMessage();
            AINCC_Logger::error('Auto-publish failed', [
                'error' => $e->getMessage()
            ]);
        } finally {
            $this->release_lock($job);
        }

        return $result;
    }

    /**
     * Process scheduled posts
     */
    public function process_scheduled(): array {
        $job = 'process_scheduled';
        $result = ['success' => false, 'processed' => 0];

        if (!$this->acquire_lock($job)) {
            $result['error'] = 'Job already running';
            return $result;
        }

        try {
            $publisher = aincc_get('publisher');

            if (!$publisher) {
                throw new Exception('Publisher not available');
            }

            $processed = $publisher->process_scheduled();
            $result['success'] = true;
            $result['processed'] = $processed;

        } catch (Throwable $e) {
            $result['error'] = $e->getMessage();
            AINCC_Logger::error('Scheduled processing failed', [
                'error' => $e->getMessage()
            ]);
        } finally {
            $this->release_lock($job);
        }

        return $result;
    }

    /**
     * Cleanup old data
     */
    public function cleanup(): array {
        $job = 'cleanup';
        $result = ['success' => false];

        if (!$this->acquire_lock($job)) {
            $result['error'] = 'Job already running';
            return $result;
        }

        try {
            $db = aincc_get('database');

            if (!$db) {
                throw new Exception('Database not available');
            }

            $retention_days = (int) AINCC_Settings::get('log_retention_days', 30);

            // Cleanup logs
            $logs_deleted = $db->cleanup_old_logs($retention_days);

            // Cleanup old raw articles (keep 7 days)
            $articles_deleted = $db->cleanup_old_raw_articles(7);

            // Cleanup failed queue items (keep 3 days)
            $queue_deleted = $db->cleanup_failed_queue_items(3);

            // Clear expired transients
            $this->cleanup_transients();

            $result = [
                'success' => true,
                'logs_deleted' => $logs_deleted,
                'articles_deleted' => $articles_deleted,
                'queue_deleted' => $queue_deleted
            ];

            AINCC_Logger::info('Cleanup completed', $result);

        } catch (Throwable $e) {
            $result['error'] = $e->getMessage();
            AINCC_Logger::error('Cleanup failed', [
                'error' => $e->getMessage()
            ]);
        } finally {
            $this->release_lock($job);
        }

        return $result;
    }

    /**
     * Cleanup expired transients
     */
    private function cleanup_transients(): void {
        global $wpdb;

        $wpdb->query(
            "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
            WHERE a.option_name LIKE '_transient_aincc_%'
            AND a.option_name NOT LIKE '_transient_timeout_aincc_%'
            AND b.option_name = CONCAT('_transient_timeout_', SUBSTRING(a.option_name, 12))
            AND b.option_value < UNIX_TIMESTAMP()"
        );
    }

    /**
     * Get cron status for all jobs
     */
    public function get_cron_status(): array {
        $crons = [
            'aincc_fetch_sources' => [
                'name' => 'Fetch RSS Sources',
                'interval' => 'every_5_minutes',
            ],
            'aincc_process_queue' => [
                'name' => 'Process Content Queue',
                'interval' => 'every_2_minutes',
            ],
            'aincc_auto_publish' => [
                'name' => 'Auto Publish',
                'interval' => 'every_5_minutes',
            ],
            'aincc_process_scheduled' => [
                'name' => 'Process Scheduled Posts',
                'interval' => 'every_5_minutes',
            ],
            'aincc_cleanup_old_data' => [
                'name' => 'Cleanup Old Data',
                'interval' => 'daily',
            ],
        ];

        $status = [];

        foreach ($crons as $hook => $info) {
            $next = wp_next_scheduled($hook);
            $lock_key = self::LOCK_PREFIX . str_replace('aincc_', '', $hook);
            $is_running = get_transient($lock_key) !== false;

            $status[$hook] = [
                'name' => $info['name'],
                'interval' => $info['interval'],
                'next_run' => $next ? date('Y-m-d H:i:s', $next) : 'Not scheduled',
                'scheduled' => (bool) $next,
                'is_running' => $is_running,
            ];
        }

        return $status;
    }

    /**
     * Manually trigger a cron job (with validation)
     */
    public function trigger_cron(string $hook): array {
        $allowed_hooks = [
            'aincc_fetch_sources' => 'fetch_sources',
            'aincc_process_queue' => 'process_queue',
            'aincc_auto_publish' => 'auto_publish',
            'aincc_process_scheduled' => 'process_scheduled',
            'aincc_cleanup_old_data' => 'cleanup',
        ];

        if (!isset($allowed_hooks[$hook])) {
            return ['success' => false, 'error' => 'Invalid cron hook'];
        }

        $method = $allowed_hooks[$hook];

        // For manual triggers, force-clear any stale locks (locks older than 5 minutes)
        $lock_key = self::LOCK_PREFIX . $method;
        $existing_lock = get_transient($lock_key);
        if ($existing_lock !== false) {
            // Check if lock is stale (older than 5 minutes)
            if (is_numeric($existing_lock) && (time() - $existing_lock) > 300) {
                delete_transient($lock_key);
                AINCC_Logger::info("Stale lock cleared for {$method}");
            } else {
                // Job is still running, return info
                return [
                    'success' => false,
                    'error' => 'Задача уже выполняется. Попробуйте через несколько минут.',
                    'running_since' => is_numeric($existing_lock) ? date('H:i:s', $existing_lock) : 'unknown',
                ];
            }
        }

        // Call the method directly - use force=true for fetch_sources to ignore time intervals
        if ($method === 'fetch_sources') {
            return $this->fetch_sources(true); // Force fetch all sources for manual triggers
        }

        return $this->$method();
    }

    /**
     * Reschedule all cron jobs
     */
    public function reschedule_all(): array {
        // Clear existing
        wp_clear_scheduled_hook('aincc_fetch_sources');
        wp_clear_scheduled_hook('aincc_process_queue');
        wp_clear_scheduled_hook('aincc_auto_publish');
        wp_clear_scheduled_hook('aincc_process_scheduled');
        wp_clear_scheduled_hook('aincc_cleanup_old_data');

        // Clear all locks
        delete_transient(self::LOCK_PREFIX . 'fetch_sources');
        delete_transient(self::LOCK_PREFIX . 'process_queue');
        delete_transient(self::LOCK_PREFIX . 'auto_publish');
        delete_transient(self::LOCK_PREFIX . 'process_scheduled');
        delete_transient(self::LOCK_PREFIX . 'cleanup');

        // Reschedule with staggered times to prevent overlap
        wp_schedule_event(time() + 30, 'every_5_minutes', 'aincc_fetch_sources');
        wp_schedule_event(time() + 90, 'every_2_minutes', 'aincc_process_queue');
        wp_schedule_event(time() + 150, 'every_5_minutes', 'aincc_auto_publish');
        wp_schedule_event(time() + 210, 'every_5_minutes', 'aincc_process_scheduled');

        // Daily cleanup at 3 AM
        $tomorrow_3am = strtotime('tomorrow 3:00am');
        wp_schedule_event($tomorrow_3am, 'daily', 'aincc_cleanup_old_data');

        AINCC_Logger::info('All cron jobs rescheduled');

        return ['success' => true, 'status' => $this->get_cron_status()];
    }

    /**
     * Get current system stats
     */
    public function get_system_stats(): array {
        return [
            'memory_used' => memory_get_usage(true),
            'memory_peak' => memory_get_peak_usage(true),
            'memory_limit' => $this->memory_limit,
            'memory_available' => $this->has_memory_available(),
            'php_version' => PHP_VERSION,
            'wp_version' => get_bloginfo('version'),
            'cron_status' => $this->get_cron_status(),
        ];
    }
}
